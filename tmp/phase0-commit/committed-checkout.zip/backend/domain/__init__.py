# Domain types and schemas
